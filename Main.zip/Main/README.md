# BCT-MiniProj-Atharva

🔗 Simple Blockchain Implementation in Python

This project implements a basic blockchain system from scratch using Python. It demonstrates the core concepts of blockchain such as block creation, hashing, chain linking, data integrity verification, and persistent storage using JSON files.

🚀 Features

Genesis block creation

SHA-256 hashing using Python’s hashlib

Block linking via previous hash

Chain validation to detect tampering

Persistent storage using JSON file handling

Automatic chain loading on restart

🛠️ How It Works

Each block contains:

Index

Timestamp

Data

Previous block hash

Current block hash

Blocks are cryptographically linked using SHA-256 hashing. The verify_chain() method ensures integrity by checking:

Previous hash linkage

Recalculated hash consistency

If any block is modified, validation fails, demonstrating blockchain immutability.

🎯 Purpose

This project is built to understand:

Core blockchain architecture

Cryptographic hashing

Data integrity verification

File-based persistence

Object-oriented programming in Python
